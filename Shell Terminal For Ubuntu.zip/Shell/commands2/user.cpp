#include<iostream>
using namespace std;
int main()
{
    string user,y,n,pass,x;
    cout<<"User is Nuha";
    cout<<endl;
    cout<<"Add New User ?"<<endl;
    cout<<"Type (Yes/No) "<<endl;
    cin>>x;
    if(y == "Yes")
    {
        cout<<"Enter User Name : ";
        cin>> user;
         cout<<endl;
        cout<<"Enter Password : ";
        cin>>pass;
         cout<<endl;
        cout<<"Enter Password Again : ";
        cin>>pass;
         cout<<endl;
        cout<<"User Added!!"<<endl;
    }
    else
       cout<<"Ok"<<endl;

}