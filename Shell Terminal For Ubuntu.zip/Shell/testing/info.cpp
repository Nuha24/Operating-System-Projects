#include<iostream>
using namespace std;
int main()
{
    string name,id,sem;
    cout<<"Enter Your Name : ";
    cin>> name;
    cout<<endl;
    cout<<"Enter Id : ";
    cin>> id;
    cout<<endl;
    cout<<"Enter Semester : ";
    cin>> sem;
    
    cout<<endl;
    cout<<"Given Name : "<< name<<endl;
    cout<<"Given ID : "<< id <<endl;
    cout<<"Given Semester : "<< sem <<endl;
}