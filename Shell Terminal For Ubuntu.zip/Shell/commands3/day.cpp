#include <iostream>
#include <cmath>
using namespace std;

string weekday[7] = {"Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"};

string zellersAlgorithm(int day, int month, int year) {
    if (month < 3) {
        month += 12;
        year--;
    }
    
    int y = year % 100;
    int c = year / 100;
    
    int w = (day + floor(13 * (month + 1) / 5) + y + floor(y / 4) + floor(c / 4) - 2 * c);
    w = (w % 7 + 7) % 7; // Ensure that w is positive and in the range 0 to 6.
    
    return weekday[w];
}

int main() 
{
    int day, month, year;
    cout<< "Enter Day: ";
    cin >> day;
    cout << "Enter Month: ";
    cin >> month;
    cout << "Enter Year: ";
    cin >> year;
    
    cout << "It was: " << zellersAlgorithm(day, month, year) << endl;
    
    return 0;
}
