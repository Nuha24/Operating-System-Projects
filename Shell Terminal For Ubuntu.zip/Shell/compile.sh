#C211224 - Nuha

# terminal screen clear
clear

# previously compiled 'calc' program remove
rm -rf commands/calc

# previously compiled 'info' program remove
rm -rf commands/info

#Calculator commands (Command File)
g++ -o commands/calc commands/calc.cpp

#Information commands (Testing File)
g++ -o testing/info testing/info.cpp

#About User commands (Commands2 File)
g++ -o commands2/user commands2/user.cpp

#Finding Day commands (Commands3 File)
g++ -o commands3/day commands3/day.cpp

# To clear Screen
clear

# 'main.cpp' source file compile & executable output show to 'shell'
g++ -o shell main.cpp

# Execute the compiled 'shell' program
./shell
